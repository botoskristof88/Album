# Órai feladatok

Ebbe a repositoryba töltöm fel az órai feladatokat. Amikor elkészlülök eggyel, itt megtalálod. 

Probléma esetén az Issues fülön belül felteheted a kérdésedet, vagy írj facebookon.

//Adawan
